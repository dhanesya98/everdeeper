@echo off
title Ever Deeper II: Abyssal Tactics
echo ======================================================
echo   EVER DEEPER II: ABYSSAL TACTICS (TURUN TERUS RPG 2)
echo   Third-Person Isometric Turn-Based RPG
echo ======================================================
echo.
echo Membuka game di browser favorit Anda...
start "" "%~dp0index.html"
echo Game telah dibuka! Selamat berpetualang di kedalaman Abyss!
timeout /t 3 >nul
exit
